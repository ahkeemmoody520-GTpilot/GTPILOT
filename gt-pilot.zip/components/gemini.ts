// Gemini service layer purged as per Directive v70.0.
// All logic has been migrated to services/gt-services.ts.
